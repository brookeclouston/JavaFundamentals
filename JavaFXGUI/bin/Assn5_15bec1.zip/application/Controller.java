/*
 * Controller class for Pizza Order System GUI. Uses FXML file to build an interactive application
 * that lets a user build a pizza, relying on Pizza.java, LineItem.java and IllegalPizza.java for the
 * creation of objects. Created for Assignment 5 CISC124 Fall 2018.
 * @author Brooke Clouston
 * Student Number: 20001003
 * NetID: 15bec1
 * Date Created: November 23 2018
 */
package application;

import javafx.event.ActionEvent;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.TextField;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.beans.property.StringProperty;
import javafx.scene.image.ImageView;

public class Controller {

	private static final long serialVersionUID = 1L;
	private static ArrayList<LineItem> orders = new ArrayList<>();
	
	// Creating the lists to populate the choiceboxes
	private ObservableList<String> sizeChoiceList = FXCollections.observableArrayList("small", "medium", "large");
	private ObservableList<String> cheeseChoiceList = FXCollections.observableArrayList("single", "double", "triple");
	private ObservableList<String> noneOrSingleList = FXCollections.observableArrayList("none", "single");
	private ObservableList<String> noneList = FXCollections.observableArrayList("none");
		
	@FXML
	private ChoiceBox<String> sizeChoice = new ChoiceBox<>();

    @FXML
    private ChoiceBox<String> cheeseChoice = new ChoiceBox<>();  

    @FXML
    private ChoiceBox<String> hamChoice = new ChoiceBox<>();
    
    @FXML
    private ChoiceBox<String> greenPepChoice = new ChoiceBox<>();
   
    @FXML
    private ChoiceBox<String> pineappleChoice = new ChoiceBox<>();
    
    @FXML
    private TextField subtotal;

    @FXML
    private TextField quantityField;
    
    @FXML
    private TextArea orderSummaryArea;

    @FXML
    private Button saveButton;

    @FXML
    private TextField totalField;

    @FXML
    private Button doneButton;
    
    @FXML
    // once the user has created the pizza, this method instantiates the Pizza object and checks for legality
    void saveToOrder(ActionEvent event) {
    	String size = sizeChoice.getValue();
    	String cheese = cheeseChoice.getValue();
    	String ham = hamChoice.getValue();
    	String greenPep = greenPepChoice.getValue();
    	String pineapple = pineappleChoice.getValue();
    	int quantity = (int) Double.parseDouble(quantityField.getText());
    	if ((quantity < 1) || (quantity > 100)) {
    	  	// Displays an error popup if illegal number of pizzas was chosen
    		Alert info = new Alert(AlertType.INFORMATION);
    		info.setGraphic(new ImageView(this.getClass().getResource("Images/sadZa.png").toString()));
    		info.setTitle("Error Alert");
        	info.setHeaderText("Illegal Number of Pizzas");
        	info.setContentText("You can't have " + quantity + " Pizzas!");
        	info.showAndWait();
        	return;
    	}
    	try {    		
    		Pizza newZa = new Pizza(size, cheese, pineapple, greenPep, ham);
    		LineItem orderDetail = new LineItem(quantity, newZa);
    		orders.add(orderDetail); // adds order to order list
    		float orderTotal = orderDetail.getCost();
    		subtotal.setText("$" + String.format("%.2f", orderTotal));
    		String currentOrder = (String) orderDetail.toString(); // adds order contents to textArea
    		orderSummaryArea.appendText(currentOrder + "\n");	
    	} catch (IllegalPizza ip) {
    		// displays popup error containing error message if an unknown error has occurred
    		Alert info = new Alert(AlertType.ERROR);
        	info.setTitle("Error Alert");
        	info.setHeaderText("Something went wrong!");
        	info.setContentText("Error message: " + ip);
        	info.showAndWait();
        	return;
    	}
    } // end saveToOrder
    
    @FXML
    // calculates the final cost of the order
    void done(ActionEvent event) {
    	float orderTotal = 0;
    	for (LineItem order : orders) {
    		orderTotal += (order.getCost());
    	}
    	totalField.setText("$" + String.format("%.2f", orderTotal));
    } // end done

    @FXML
    void initialize() {
    	// sets the initial choicebox items and lists
    	sizeChoice.setValue("small");
    	sizeChoice.setItems(sizeChoiceList);
    	
    	cheeseChoice.setValue("single");
    	cheeseChoice.setItems(cheeseChoiceList);
       
    	hamChoice.setValue("none");
    	hamChoice.setItems(noneOrSingleList);
        
    	pineappleChoice.setValue("none");
		greenPepChoice.setValue("none");
    
    	// Adds listener to quantity field to prevent non integer values being entered
    	quantityField.textProperty().addListener((observableValue, oldText, newText) ->
    	{
    		if (newText != null && !newText.isEmpty()) {
	    		try {
	    			int aVal = Integer.parseInt(newText);
	    		} catch (NumberFormatException e) {
	    			((StringProperty)observableValue).setValue(oldText);
	    		}
    		}
    	}); // end quantity field listener 
    	
    	// Adds listener to hamChoice which determines what the user is able to do with the green pepper and pineapple choices 
    	hamChoice.valueProperty().addListener((ObservableValue, oldVal, newVal) ->
    	{
    		switch (newVal) {
    		case "single" :
    			greenPepChoice.setItems(noneOrSingleList);
    			pineappleChoice.setItems(noneOrSingleList);
    			break;
    			
    		case "none" :
    			greenPepChoice.setItems(noneList);
    			pineappleChoice.setItems(noneList);
    			break;	
    		}
    		pineappleChoice.setValue("none");
			greenPepChoice.setValue("none");	
    	}); // end hamChoice listener 	
    } // end initialize 
}